package com.example.lab1shubhneetsingh;

import javafx.fxml.FXML;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.net.URL;
import java.util.ResourceBundle;
import java.sql.*;
public class HelloController implements Initializable {
    @FXML
    private TableView<songdub> tableView;
    @FXML
    private TableColumn<songdub, Integer> SongID;
    @FXML
    private TableColumn<songdub, String> SongName;
    @FXML
    private TableColumn<songdub, String> ArtistName;
    @FXML
    private TableColumn<songdub, Integer> artist_id;
    ObservableList<songdub> list = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        SongID.setCellValueFactory(new
                PropertyValueFactory<songdub, Integer>("SongID"));
        SongName.setCellValueFactory(new
                PropertyValueFactory<songdub, String>("SongName"));
        ArtistName.setCellValueFactory(new
                PropertyValueFactory<songdub, String>("ArtistName"));
        artist_id.setCellValueFactory(new
                PropertyValueFactory<songdub, Integer>("artist_id"));
        tableView.setItems(list);
    }

    @FXML
    protected void onHelloButtonClick() {
        populateTable();
    }

    public void populateTable() {
        // Establish a database connection
        String jdbcUrl = "jdbc:mysql://localhost:3306/doctorsdatatable";
        String dbUser = "root";
        String dbPassword = "";
        try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser,
                dbPassword)) {
            // Execute a SQL query to retrieve data from the database
            String query = "SELECT * FROM musiclabels";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            // Populate the table with data from the database
            while (resultSet.next()) {
                int SongID = resultSet.getInt("SongID");
                String SongName = resultSet.getString("SongName");
                String ArtistName = resultSet.getString("ArtistName");
                int artist_id = resultSet.getInt("artist_id");
                tableView.getItems().add(new songdub(SongID, SongName, ArtistName,
                        artist_id));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
