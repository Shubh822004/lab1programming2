package com.example.lab1shubhneetsingh;

public class songdub {
    private int SongID;
    private String SongName;
    private String ArtistName;
    private int artist_id;
    public songdub(int SongID, String SongName, String ArtistName, int artist_id) {
        this.SongID = SongID;
        this.SongName = SongName;
        this.ArtistName = ArtistName;
        this.artist_id = artist_id;
    }

    public int getSongID() {
        return SongID;
    }
    public String getSongName(){
        return SongName;
    }
    public String getArtistName(){
        return ArtistName;
    }
    public int getArtist_id(){
        return artist_id;
    }





}




